class NewsVeracityApp {
    constructor() {
        this.initEventListeners();
        this.checkServerHealth();
    }

    initEventListeners() {
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchTab(e.target.dataset.tab);
            });
        });

        // Analyze URL
        document.getElementById('analyze-url').addEventListener('click', () => {
            this.analyzeUrl();
        });

        // Analyze Text
        document.getElementById('analyze-text').addEventListener('click', () => {
            this.analyzeText();
        });

        // Enter key support
        document.getElementById('news-url').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.analyzeUrl();
        });

        document.getElementById('news-text').addEventListener('keypress', (e) => {
            if (e.ctrlKey && e.key === 'Enter') this.analyzeText();
        });
    }

    switchTab(tabId) {
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(tabId).classList.add('active');
    }

    async analyzeUrl() {
        const url = document.getElementById('news-url').value.trim();
        
        if (!url) {
            this.showError('Please enter a URL to analyze');
            return;
        }

        if (!this.isValidUrl(url)) {
            this.showError('Please enter a valid URL');
            return;
        }

        await this.analyze({ url });
    }

    async analyzeText() {
        const text = document.getElementById('news-text').value.trim();
        
        if (!text) {
            this.showError('Please enter some text to analyze');
            return;
        }

        if (text.length < 50) {
            this.showError('Please enter at least 50 characters for analysis');
            return;
        }

        await this.analyze({ text });
    }

    async analyze(data) {
        this.showLoading();
        this.hideResults();
        this.hideError();

        try {
            const response = await fetch('/analyze', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || 'Analysis failed');
            }

            if (result.error) {
                throw new Error(result.error);
            }

            this.showResults(result);
            
        } catch (error) {
            console.error('Analysis error:', error);
            this.showError(error.message);
        } finally {
            this.hideLoading();
        }
    }

    showResults(result) {
        const resultsSection = document.getElementById('results-section');
        const verdictIcon = document.getElementById('verdict-icon');
        const verdictText = document.getElementById('verdict-text');
        const confidenceFill = document.querySelector('.confidence-fill');
        const confidenceText = document.getElementById('confidence-text');
        const articleInfo = document.getElementById('article-info');

        // Update verdict
        verdictText.textContent = result.verdict;
        verdictText.className = `verdict-text ${result.verdict.toLowerCase()}`;

        // Update icon
        verdictIcon.innerHTML = '';
        let iconClass = 'fas fa-question-circle';
        if (result.verdict === 'REAL') {
            iconClass = 'fas fa-check-circle';
        } else if (result.verdict === 'FAKE') {
            iconClass = 'fas fa-times-circle';
        }
        verdictIcon.innerHTML = `<i class="${iconClass}"></i>`;
        verdictIcon.className = `verdict-icon ${result.verdict.toLowerCase()}`;

        // Update confidence meter
        confidenceFill.style.width = `${result.confidence}%`;
        confidenceFill.className = `confidence-fill ${result.verdict.toLowerCase()}`;
        confidenceText.textContent = `Confidence: ${result.confidence}%`;

        // Show article info if available
        if (result.article_info) {
            document.getElementById('article-title').textContent = result.article_info.title;
            document.getElementById('article-link').href = result.article_info.source;
            articleInfo.classList.remove('hidden');
        } else {
            articleInfo.classList.add('hidden');
        }

        // Show results
        resultsSection.classList.remove('hidden');
    }

    showLoading() {
        document.getElementById('loading-section').classList.remove('hidden');
        document.querySelectorAll('.analyze-btn').forEach(btn => {
            btn.disabled = true;
        });
    }

    hideLoading() {
        document.getElementById('loading-section').classList.add('hidden');
        document.querySelectorAll('.analyze-btn').forEach(btn => {
            btn.disabled = false;
        });
    }

    showError(message) {
        const errorSection = document.getElementById('error-section');
        document.getElementById('error-message').textContent = message;
        errorSection.classList.remove('hidden');
    }

    hideError() {
        document.getElementById('error-section').classList.add('hidden');
    }

    hideResults() {
        document.getElementById('results-section').classList.add('hidden');
    }

    isValidUrl(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }

    async checkServerHealth() {
        try {
            const response = await fetch('/health');
            const data = await response.json();
            
            if (!data.ollama_running) {
                this.showError('Warning: Ollama server is not running. Please ensure Ollama is installed and running on localhost:11434');
            }
        } catch (error) {
            console.warn('Health check failed:', error);
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new NewsVeracityApp();
});